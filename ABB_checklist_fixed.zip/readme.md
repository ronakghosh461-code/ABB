# ABB Site Checklist (QR)

Mobile-first QR checklist app (Node.js + Express + SQLite).

## Run locally
    npm install
    cp .env.example .env   # then edit
    npm start              # http://localhost:3000

## Deploy (Render)
1. Push this repo to GitHub (GitHub Pages cannot run it - it needs a Node host).
2. Render -> New -> Blueprint -> select the repo (uses `render.yaml`).
3. Set `ADMIN_PASSWORD` in the Render dashboard.
4. Open the `.onrender.com` URL. Admin: `/admin`, master QR: `/admin/qr`.

Note: Render's free plan has no persistent disk, so the SQLite DB and uploaded photos reset on restart. Use a paid disk mounted at `/opt/render/project/src/data` for permanence.
